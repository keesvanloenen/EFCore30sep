﻿namespace School.ConsoleApp.Models;

public class Instructor: Person
{
    public DateOnly HireDate { get; set; }
}
