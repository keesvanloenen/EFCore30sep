﻿namespace School.ConsoleApp.Models;

public class OnlineCourse : Course
{
    public string Url { get; set; } = null!;
}
