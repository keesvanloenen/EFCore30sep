﻿namespace School.ConsoleApp.Models;

public class DepartmentAdministrator: Instructor
{
}
