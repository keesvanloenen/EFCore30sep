﻿namespace School.ConsoleApp.Models;

public class Student: Person
{
    public DateOnly EnrollmentDate { get; set; }
}
